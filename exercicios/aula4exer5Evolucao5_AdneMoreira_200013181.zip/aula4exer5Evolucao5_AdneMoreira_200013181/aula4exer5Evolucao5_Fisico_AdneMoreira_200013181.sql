--   ----------------- AULA4EXER5EVOLUCAO5 ----------------
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 07/12/2022
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao5
--
-- Ultimas Alteracoes
--   07/12/2022 => Criação do script
--   13/12/2022 => Alteração da chave primaria de consulta
-- 
--              
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 		   => 02 Procedimento
-- 		   => 09 Funções
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer5Evolucao5;

USE aula4exer5Evolucao5;

CREATE TABLE MEDICO (
    numero INT NOT NULL,
    unidadeFederativa VARCHAR(2) NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
    
    CONSTRAINT MEDICO_PK PRIMARY KEY (numero, unidadeFederativa)
);

CREATE TABLE PACIENTE (
    idPaciente INT NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
    dataNascimento DATE,
    sexo VARCHAR(9),
    cep INT(8),
    estado VARCHAR(25),
    cidade VARCHAR(50),
    pais VARCHAR(50),
    rua VARCHAR(50),
    numero INT,
    complemento VARCHAR(100),
    
    CONSTRAINT PACIENTE_PK PRIMARY KEY (idPaciente)
);

CREATE TABLE CONSULTA (
	idConsulta INT, 
    data DATE NOT NULL,
    horario TIME NOT NULL,
    numero INT NOT NULL,
    unidadeFederativa VARCHAR(2) NOT NULL,
    idPaciente INT NOT NULL,
    
    CONSTRAINT CONSULTA_PK PRIMARY KEY (idConsulta),
	CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY (numero, unidadeFederativa) 
    REFERENCES MEDICO (numero, unidadeFederativa),
	CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (idPaciente) 
    REFERENCES PACIENTE (idPaciente)
);

CREATE TABLE RECEITA (
    idReceita INT(5) NOT NULL ,
    idConsulta INT(5) NOT NULL, 
    posologia VARCHAR(100),
    
    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
	CONSTRAINT RECEITA_CONSULTA_FK FOREIGN KEY (idConsulta)
    REFERENCES CONSULTA (idConsulta)
   
);

CREATE TABLE ESPECIALIDADE (
    idEspecialidade INT(5) NOT NULL,
    nomeEspecialidade VARCHAR(100) NOT NULL,
    
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY (idEspecialidade)
);

CREATE TABLE MEDICAMENTO (
    idMedicamento INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    principioAtivo VARCHAR(50),
    
    CONSTRAINT MEDICAMENTO_PK PRIMARY KEY (idMedicamento)
);

CREATE TABLE telefone (
    idPaciente INT NOT NULL,
    telefone BIGINT(11) NOT NULL,
    
    CONSTRAINT telefone_PACIENTE_FK FOREIGN KEY (idPaciente) 
    REFERENCES PACIENTE(idPaciente)
);

CREATE TABLE tem (
    idEspecialidade INT NOT NULL,
    numero INT NOT NULL,
    unidadeFederativa VARCHAR(2) NOT NULL,
    
    CONSTRAINT tem_ESPECIALIDADE_FK FOREIGN KEY (idEspecialidade) 
    REFERENCES ESPECIALIDADE (idEspecialidade),
    CONSTRAINT tem_MEDICO_FK FOREIGN KEY (numero, unidadeFederativa) 
    REFERENCES MEDICO (numero, unidadeFederativa)
);

CREATE TABLE possui (
    idMedicamento INT NOT NULL,
    idReceita INT,
    
	CONSTRAINT possui_MEDICAMENTO_FK FOREIGN KEY (idMedicamento) 
    REFERENCES MEDICAMENTO (idMedicamento),
	CONSTRAINT possui_RECEITA_FK FOREIGN KEY (idReceita) 
    REFERENCES RECEITA (idReceita)
);
