-- ----------------- AULA4EXER5EVOLUCAO5 ----------------
--                 SCRIPT DE MANIPULACAO (DML)
--
-- Data Criacao ...........: 14/12/2022
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao5
--
-- Ultimas Alteracoes
--  14/12/2022 => Criação do script
--  17/12/2022 => Adição de 3 tuplas para cada tabela
--              
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 		   => 09 funcoes
-- ---------------------------------------------------------

USE aula4exer5Evolucao5;

INSERT INTO MEDICO VALUES(
	237481, 
    'DF', 
    'João Pedro Chaves'
),
(
	677463, 
    'GO',
    'Caio Vitor Santos'
), 
(
	754387, 
    'DF', 
    'Joana Linhares'
), 
(
	267452, 
    'DF', 
    'Carla Cavalcanti'
), 
(
	899874, 
    'DF', 
    'Nicole Barros'
), 
(
	456352, 
    'DF', 
    'Miguel de Oliveira'
);

INSERT INTO PACIENTE VALUES(
	1, 
    'Joanes Carvalho Santos', 
    '1978-06-11',
	'masculino', 
    72760-112,
    'Distrito Federal',
    'Braslandia',
    'Brasil', 
    'Rua 11', 
    23, 
    'Incra 8'
), 
(
	 2, 
    'Dafne Moretti Moreira',
    '2000-10-17',
    'feminino', 
    77036271,
    'Distrito Federal',
    'Brasília',
    'Brasil', 
    'Rua três', 
    15, 
    'Setor Bueno'
), 
(
	 3,  
    'Joana Linhares',
    '2002-02-28',
	'feminino', 
    72543230,
    'Distrito Federal',
    'Santa Maria',
    'Brasil', 
    'Rua Magalhaes', 
    15, 
    'Quadra CL 213'
), 
(
	4, 
    'Maria Alzira dos Santos', 
    '1975-09-09',
	'feminino', 
    70296-040,
    'Distrito Federal',
    'Brasília',
    'Brasil', 
    'Quadra SQS', 
    413, 
    'Bloco D'
), 
(
	5, 
    'Pedro Alves', 
    '1982-11-03',
	'masculino', 
    71995-195,
    'Distrito Federal',
    'Águas Claras',
    'Brasil', 
    'Conjunto SHA Conjunto 5', 
    27, 
    'Setor Habitacional Arniqueira'
),
(
	6, 
    'João Vitor Magalhães', 
    '1978-06-11',
	'masculino', 
    72760-112,
    'Distrito Federal',
    'Núcleo Bandeirante',
    'Brasil', 
    'Rua 11', 
    2, 
    'Metropolitana'
);

INSERT INTO CONSULTA VALUES(
	1, 
	'2022-12-13', 
    '09:00:00',
    754387, 
    'DF', 
    3
),
(
	2, 
	'2022-12-20', 
    '10:30:00',
    677463,
    'GO', 
    2
),
(
	3,
	'2022-12-16', 
    '14:00:00',
    237481,
    'DF', 
    1
),
(
	4,
	'2022-12-16', 
    '14:00:00',
    267452, 
    'DF',
    6
),
(
	5,
	'2022-12-16', 
    '14:00:00',
    899874, 
    'DF',  
    4
),
(
	6,
	'2022-12-16', 
    '14:00:00',
	456352, 
    'DF', 
    5
);


INSERT INTO RECEITA VALUES(
    1,
    1,
    'De 8 em 8h'
),
(
    2,
    2, 
    '2 vezes ao dia'
),
(
    3,
    3, 
    'De 4 em 4h'
),
(
    4,
    4, 
    'De 12 em 12h'
),
(
    5,
    5, 
    'De 8 em 8h'
),
(
    6,
    6, 
    '1 vez por dia'
);

INSERT INTO ESPECIALIDADE VALUES(
	1, 
    'Cardiologista'
),
(
	2, 
    'Oftalmologista'
),
(
	3, 
    'Pediatra'
), 
(
	4, 
    'Ortopedista'
), 
(
	5, 
    'Otorrinolaringologista'
), 
(
	6, 
    'Dermatologista'
);

INSERT INTO MEDICAMENTO VALUES (
    1,
    'Dipirona Monoidratada',
    'Dipirona Sódica'
),
(
    2,
    'Ibuprofeno',
    'Derivado do ácido fenilpropiônico'
),
(
    3,
    'Amoxicilina',
    'Amoxicilina'
), 
(
    4,
    'Dorflex',
    'dipirona monoidratada e citrato de orfenadrina'
), 
(
    5,
    'Loratadina',
    'Loratadina'
), 
(
    6,
    'Paracetamol',
    'Paracetamol'
);

INSERT INTO telefone VALUES
(1, 998627181), 
(2, 993238991), 
(3, 998873821),
(4, 993441318), 
(5, 995378511), 
(6, 995547387);

INSERT INTO tem VALUES(
    1,
    237481,
    'DF'
), 
(
    2,
    677463,
    'GO'
),
(
    3,
    754387,
     'DF'
), 
(
    4,
    267452, 
    'DF'
), 
(
    5,
    899874, 
    'DF'
), 
(
    6,
    456352, 
    'DF'
);

INSERT INTO possui VALUES(
    2,
	2
),
(
    1,
    3
),
(
    3,
    1
), 
(
    4,
    5
), 
(
    5,
    4
), 
(
    6,
    6
);