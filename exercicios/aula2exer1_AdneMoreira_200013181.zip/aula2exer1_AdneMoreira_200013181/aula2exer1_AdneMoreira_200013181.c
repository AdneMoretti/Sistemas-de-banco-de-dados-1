#include <stdio.h>
#include <stdlib.h>


typedef struct pessoa{
    int chave;
    char nome[100];
    char cpf[12];
    char endereco[102];
} Pessoa;

typedef struct carro{
    int chave;
    char modelo[101];
    char cor[101];
    char renavam[12];
    char placa[10];
    char chassi[102];
    Pessoa pessoa;
} Carro;

void ler_pessoas(){
    FILE *ponteiro;
    Pessoa pessoa;
    ponteiro = fopen("arq_pessoas.bin","rb");
    while(fread(&pessoa,sizeof(pessoa),1,ponteiro) != 0) 
    {                    
    printf("%d\n%s\n%s\n%s\n", pessoa.chave, pessoa.nome, pessoa.cpf, pessoa.endereco);
    }
    fclose(ponteiro);
}

void ler_carros(){
    FILE *ponteiro;
    Carro carro;
    ponteiro = fopen("arq_carros.bin","rb");
    while(fread(&carro,sizeof(carro),1,ponteiro) != 0) 
    {                    
    printf("%d\n%s\n%s\n%s\n%s\n", carro.chave, carro.modelo, carro.cor, carro.renavam, carro.placa);
    }
    fclose(ponteiro);
}

FILE *abrir_arquivo(char nome[15]){
    FILE *arquivo;
    if((arquivo = fopen(nome, "w"))== NULL){
        printf("Erro na abertura do arquivo");
        exit(1);
    }
    return arquivo;
}

int main(){
    FILE *arq_pessoas = abrir_arquivo("arq_pessoas.bin");
    FILE *arq_carros = abrir_arquivo("arq_carros.bin");
    int cnt=0;
    int num;

    int escolha;
    Pessoa pessoa;
    Carro carro;
    int id_pessoas = 1;
    int id_carros = 1;
    do{
        printf("Escolha: \n1- Cadastrar pessoa\n2-Sair\n");
        scanf("%d", &escolha);
        switch(escolha){
            case 1: 
                printf("Insira o nome da pessoa: ");
                scanf(" %[^\n]", pessoa.nome);
                printf("Insira o cpf: ");
                scanf(" %s", pessoa.cpf);
                printf("Insira o endereco: ");
                scanf(" %[^\n]", pessoa.endereco);
                printf("Quantos carros são de sua propriedade? ");
                scanf("%d", &num);
                pessoa.chave = id_pessoas++;
                fwrite(&pessoa, sizeof(Pessoa), 1, arq_pessoas);
                for(int j=0;j<num;j++){
                    printf("---- Carro %d ----\n", j+1);
                    printf("Insira o modelo do carro: ");
                    scanf(" %[^\n]", carro.modelo);
                    printf("Insira a cor do carro: " );
                    scanf(" %[^\n]", carro.cor);
                    printf("Insira o renavam do carro: ");
                    scanf(" %[^\n]", carro.renavam);
                    printf("Insira a placa: ");
                    scanf(" %[^\n]", carro.placa);
                    printf("Insira o chassi do carro: ");
                    scanf(" %[^\n]", carro.chassi);
                    carro.pessoa = pessoa;
                    carro.chave = id_carros++;

                    fwrite(&carro, sizeof(Carro), 1, arq_carros);
                }
                break;
            case 2: 
            printf("Dados guardados no arquivo!");
                break;

            default: 
                printf("Por favor selecione entre as opcoes disponieis");
        }
    }while(escolha!=2);
    fclose(arq_pessoas);
    fclose(arq_carros);
    printf("---------------Dados dos carros----------------\n");
    ler_carros();
    printf("---------------Dados dapess pessoas----------------\n");
    ler_pessoas();
}
    
