﻿-- --------  << AULA 4 EXERCICIO 5 EVOLUCAO 3 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 07/12/2022
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao3
--
-- Ultimas Alteracoes
--   07/12/2022 => Criação do script
--
--
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
--
-- ---------------------------------------------------------

 CREATE DATABASE aula4exer5Evolucao3;
 CREATE TABLE MEDICO(
 	nomeCompleto char(100) NOT NULL,
 	numeroCrm	int NOT NULL, 
 	unidadeFederativa char(2) NOT NULL 
 	PRIMARY KEY (numeroCrm, unidadeFederativa),
 	
 );
  CREATE TABLE PACIENTE(
  	idPaciente int NOT NULL, 
 	nomeCompleto char(100) NOT NULL,
 	sexo	char(10) NOT NULL,
 	idade   int,  
 	rua 	char(50), 
 	numero	 int, 
 	cep int NOT NULL,
 	PRIMARY_KEY (idPaciente)
 );
  CREATE TABLE CONSULTA(
  	idConsulta int NOT NULL, 
 	dataConsulta date NOT NULL,
 	horarioConsulta time NOT NULL,
 	numeroCrm	int NOT NULL, 
 	unidadeFederativa char(2) NOT NULL
 );
 CREATE TABLE ESPECIALIDADE(
  	idEspecialidade int NOT NULL, 
 	nomeEspecialidade char(30) NOT NULL,
 	PRIMARY_KEY (idEspecialidade)
 );
  CREATE TABLE possui(
	numeroCrm	int NOT NULL, 
	idEspecialidade int NOT NULL, 
 	unidadeFederativa char(2) NOT NULL,
 	PRIMARY_KEY (idEspecialidade),
 	CONSTRAINT FK_MEDICO FOREIGN KEY (numeroCrm, unidadeFederativa)
 	REFERENCES MEDICO(numeroCrm, unidadeFederativa),
 	CONSTRAINT FK_ESPECIALIDADE FOREIGN KEY (idEspecialidade)
 	REFERENCES ESPECIALIDADE(idEspecialidade)
 );
 CREATE TABLE tem(
	telefone	int NOT NULL, 
 	idPaciente char(2) NOT NULL,
 	PRIMARY_KEY (idEspecialidade),
 	CONSTRAINT FK_MEDICAMENTO FOREIGN KEY (idMedicamento)
 	REFERENCES MEDICAMENTO(idMedicamento),
 	CONSTRAINT FK_RECEITA FOREIGN KEY (idReceita)
 	REFERENCES RECEITA(idReceita)
 );
 CREATE TABLE MEDICAMENTO(
	idMedicamento	int NOT NULL, 
 	nomeMedicamento char(30) NOT NULL,
 	PRIMARY_KEY (idMedicamento)
 );

