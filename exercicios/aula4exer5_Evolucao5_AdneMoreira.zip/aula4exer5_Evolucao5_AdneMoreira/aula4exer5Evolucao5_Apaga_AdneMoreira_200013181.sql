-- ----------------- AULA4EXER5EVOLUCAO5 ------------------
--               SCRIPT DE MANIPULACAO (DML)
--
-- Data Criacao ...........: 13/12/2022
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao5
--
-- Ultimas Alteracoes
--   13/12/2022 => Criação do script
--              
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 		   => 09 Procedimentos
-- ---------------------------------------------------------

DROP TABLE possui;
DROP TABLE tem;
DROP TABLE ESPECIALIDADE; 
DROP TABLE RECEITA;
DROP TABLE CONSULTA;
DROP TABLE telefone;
DROP TABLE PACIENTE;
DROP TABLE MEDICO;
DROP TABLE MEDICAMENTO;

