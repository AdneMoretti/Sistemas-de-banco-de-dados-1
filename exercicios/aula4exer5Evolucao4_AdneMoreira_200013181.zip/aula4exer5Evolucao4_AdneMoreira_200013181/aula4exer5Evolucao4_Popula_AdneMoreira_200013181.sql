-- ----------------- AULA4EXER5EVOLUCAO4 ----------------
--                 SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 07/12/2022
-- Autor(es) ..............: Alex GAbriel Alves Faustino
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao4
--
-- Ultimas Alteracoes
--  14/12/2022 => Criação do script
--              
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 		   => 27 funcoes
-- ---------------------------------------------------------

USE aula4exer5Evolucao4;

INSERT INTO MEDICO VALUES(
	237481, 
    'DF', 
    'João Pedro Chaves'
);
INSERT INTO MEDICO VALUES(
	677463, 
    'GO',
    'Caio Vitor Santos'
);
INSERT INTO MEDICO VALUES(
	754387, 
    'DF', 
    'Joana Linhares'
);

INSERT INTO PACIENTE VALUES(
	1, 
    'Joanes Carvalho Santos', 
    '1978-06-11',
	'masculino', 
    72760-112,
    'Distrito Federal',
    'Braslandia',
    'Brasil', 
    'Rua 11', 
    23, 
    'Incra 8'
);
INSERT INTO PACIENTE VALUES(
	 2, 
    'Dafne Moretti Moreira',
    '2000-10-17',
    'feminino', 
    77036271,
    'Distrito Federal',
    'Brasília',
    'Brasil', 
    'Rua três', 
    15, 
    'Setor Bueno'
);
INSERT INTO PACIENTE VALUES(
	 3,  
    'Joana Linhares',
    '2002-02-28',
	'feminino', 
    72543230,
    'Distrito Federal',
    'Santa Maria',
    'Brasil', 
    'Rua Magalhaes', 
    15, 
    'Quadra CL 213'
);

INSERT INTO CONSULTA VALUES(
	1, 
	'2022-12-13', 
    '09:00:00',
    754387, 
    'DF', 
    3
);
INSERT INTO CONSULTA VALUES(
	2, 
	'2022-12-20', 
    '10:30:00',
    677463,
    'GO', 
    2
);
INSERT INTO CONSULTA VALUES(
	3,
	'2022-12-16', 
    '14:00:00',
    237481,
    'DF', 
    1
);


INSERT INTO RECEITA VALUES(
    1,
    1,
    'De 8 em 8h'
);
INSERT INTO RECEITA VALUES(
    2,
    2, 
    '2 vezes ao dia'
);
INSERT INTO RECEITA VALUES(
    3,
    3, 
    'De 4 em 4h'
);

INSERT INTO ESPECIALIDADE VALUES(
	1, 
    'Cardiologista'
);
INSERT INTO ESPECIALIDADE VALUES(
	2, 
    'Oftalmologista'
);
INSERT INTO ESPECIALIDADE VALUES(
	3, 
    'Pediatra'
);

INSERT INTO MEDICAMENTO VALUES (
    1,
    'Dipirona Monoidratada',
    'Dipirona Sódica'
);
INSERT INTO MEDICAMENTO VALUES (
    2,
    'Ibuprofeno',
    'Derivado do ácido fenilpropiônico'
);
INSERT INTO MEDICAMENTO VALUES (
    3,
    'Amoxicilina',
    'Amoxicilina'
);

INSERT INTO telefone VALUES(1, 998627181);
INSERT INTO telefone VALUES(1, 993238991);
INSERT INTO telefone VALUES(1, 9988738219);

INSERT INTO tem VALUES(
    1,
    237481,
    'DF'
);

INSERT INTO tem VALUES(
    2,
    677463,
    'GO'
);

INSERT INTO tem VALUES(
    3,
    754387,
     'DF'
);
INSERT INTO possui VALUES(
    2,
	2
);
INSERT INTO possui VALUES(
    1,
    3
);
INSERT INTO possui VALUES(
    1,
    2
);