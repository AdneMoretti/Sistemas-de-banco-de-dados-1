-- ----------------- AULA4EXER6 --------------------------
--                 SCRIPT DE MANIPULACAO (DML)
--
-- Data Criacao ...........: 21/12/2022
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6
--
-- Ultimas Alteracoes
--  21/12/2022 => Criação do script
--              
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- ---------------------------------------------------------

USE aula4exer6;


INSERT INTO PROPRIETARIO VALUES(
    05508754261,
    'Joao Costa da Silva',
    '1982-02-28',
    40, 
    'masculino',
     72760-112,
    'Distrito Federal',
    'Braslandia', 
    'Rua 11', 
    23, 
    'Incra 8'
), 
(
    06435267117,
    'Caio Vitor Santos',
    '1975-01-09',
    47, 
    'masculino',
	72543230,
    'Distrito Federal',
    'Santa Maria',
    'Rua Magalhaes', 
    15, 
    'Quadra CL 213'
), 
(
    054467642116,
    'Aline Ferreira',
    '2000-06-22',
    22, 
    'feminino',
	77036271,
    'Goiás',
    'Goiânia',
    'Rua três', 
    15, 
    'Setor Bueno'
);

INSERT INTO MODELO VALUES(
    564782,
    'GOL 1.8'
), 
(
    989954,
    'UNO CS'
), 
(
    122765,
    'GOL MI'
);

INSERT CATEGORIA VALUES(
    11,
    'AUTOMÓVEL'
),
(
    12,
    'MOTOCICLETA'
), 
(
    13, 
    'CAMINHÃO'
);

INSERT INTO VEICULO VALUES(
    'KJU123',
    '50zJGUr9paAlF8280',
    'azul',
    2011,
    05508754261, 
    564782, 
    11
), 
(
    'PQW5623',
    '2V0YndLUeclWH9854',
    'preto',
    2015,
    054467642116, 
    989954, 
    11
), 
(
    'KJU1243',
    '251C8zPdAABf69795',
    'prata',
    2017,
    06435267117, 
    122765, 
    11
);


INSERT INTO telefone VALUES (
	06435267117,
    61993127632
), 
(
	054467642116,
    62995378511
), 
(
	05508754261,
    61984433112
);


INSERT INTO LOCAL VALUES(
	1,
    80,
    33,
    50
),
(
	2,
    40,
    65,
    70
),
(
	3,
    30,
    10,
    15
);
INSERT INTO INFRACAO VALUES(
    1,
    '2022-12-21',
    '10:00:00', 
    'ESTACIONAR NA CALÇADA',
    200.00, 
    'multa', 
    60, 
    1, 
    7625311241, 
    'KJU123'
), 
(
    2,
    '2022-06-19',
    '18:00:00', 
    'VELOCIDADE ACIMA',
    '144,00', 
    'multa', 
    110, 
   3, 
    2553689231, 
    'PQW5623'
), 
(
    3,
    '2022-10-09',
    '12:00', 
    'VELOCIDADE ACIMA',
    132,30, 
    'multa', 
    100, 
    3,
    2010562731, 
    'KJU1243'
);


INSERT INTO AGENTE VALUES(
    2553689231,
    'Jorge Henrique',
    '2020-01-02',
    5
), 
(
    2010562731,
    'Vinicius Silva',
    '2019-01-02',
    10
), 
(
    7625311241,
    'Matheus Fernandes',
    '2016-07-17',
    2
);
