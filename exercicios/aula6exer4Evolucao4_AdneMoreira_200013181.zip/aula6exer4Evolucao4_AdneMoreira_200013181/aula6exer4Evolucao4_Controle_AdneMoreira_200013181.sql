/*﻿-- --------  << aula6exer4evolucao4 >>  ----------
--
--                    SCRIPT DE CONTROLE (DML)
--
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Alex Gabriel Alves Faustino
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula6exer4evolucao2
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- ---------------------------------------------------------*/

USE aula6exer4evolucao4;

CREATE USER 'administrador' 
   IDENTIFIED BY '123admin';
   
GRANT ALL PRIVILEGES 
  ON aula6exer4evolucao3.* TO 'administrador'
  WITH GRANT OPTION;

CREATE USER 'funcionario' 
   IDENTIFIED BY 'usu123';

GRANT SELECT ON aula6exer4evolucao2.* TO 'funcionario';
GRANT INSERT ON aula6exer4evolucao2.DEPENDENTE TO 'funcionario';
