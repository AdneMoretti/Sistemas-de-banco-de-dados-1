-- ---------------------   << TF_Tema1_Controle_Final_AlexFaustino >>   ---------------------
--
--                                   SCRIPT DE CONTROLE (DDL)                                   
-- 
-- Data Criacao ...........: 06/02/2023
-- Autor(es) ..............: Adne Moreira, Alex Faustino, Ana Massuh, Cainã Freitas, Carlos Nascimento, Cristian Furtado, Davi Silva, Gabriel Oliveira, Gabriel Souza
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_Tema1_AlexFaustino
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
--         => 03 Perfis
--         => 13 Usuários
--
-- Ultimas Alteracoes
--   12/02/2023 => ALTERACAO: Nome dos perfis
-- 
-- ---------------------------------------------------------

USE TF_Tema1_AlexFaustino;

-- Criando os Perfis do projeto	
CREATE ROLE administrador;
CREATE ROLE autonomo;
CREATE ROLE cliente;	

-- Criando Usuarios do Projeto 

CREATE USER Jeysel
	IDENTIFIED BY 'lesyeJ2023!';

CREATE USER Jhon
	IDENTIFIED BY 'nohJ2023!';

CREATE USER Lennon
	IDENTIFIED BY 'nonneL2023!';
    
CREATE USER Davi
	IDENTIFIED BY 'ivaD2023.';

CREATE USER Caina
	IDENTIFIED BY 'aniaC2023!';
  
CREATE USER Maria
	IDENTIFIED BY 'airaM2023.';
  
CREATE USER Carlos
	IDENTIFIED BY 'solraC2023!';

CREATE USER Mayla
	IDENTIFIED BY 'alyaM2023.';

CREATE USER Jairo
	IDENTIFIED BY 'oriaJ2023!';

CREATE USER Paulo
	IDENTIFIED BY 'oluaP2023.';

CREATE USER Marcos
	IDENTIFIED BY 'socraM2023!';
    
CREATE USER Gabriel
	IDENTIFIED BY 'leirbaG2023.';

CREATE USER Nicolas
	IDENTIFIED BY 'salociN2023!';
    
-- Privilégios do administrador
GRANT ALL PRIVILEGES 
	ON TF_Tema1_AlexFaustino.* 
    TO administrador;
    
-- Privilégios do(a) autonomo
GRANT SELECT
	ON TF_Tema1_AlexFaustino.CLIENTE
    TO autonomo;  

GRANT SELECT, INSERT, UPDATE
	ON TF_Tema1_AlexFaustino.AUTONOMO
    TO autonomo;  

GRANT SELECT, INSERT
	ON TF_Tema1_AlexFaustino.AREAATUACAO
    TO autonomo;

GRANT SELECT
	ON TF_Tema1_AlexFaustino.MENSALIDADE
    TO autonomo; 
    
GRANT SELECT, UPDATE, INSERT
	ON TF_Tema1_AlexFaustino.SERVICO
    TO autonomo;

GRANT ALL PRIVILEGES 
	ON TF_Tema1_AlexFaustino.atua
    TO autonomo;

GRANT ALL PRIVILEGES 
	ON TF_Tema1_AlexFaustino.compoe
    TO autonomo;

GRANT SELECT
	ON TF_Tema1_AlexFaustino.AVALIACAO
    TO autonomo;

GRANT SELECT
	ON TF_Tema1_AlexFaustino.PAGAMENTO
    TO autonomo;

GRANT SELECT, UPDATE, INSERT
	ON TF_Tema1_AlexFaustino.ATENDIMENTO
    TO autonomo;
    
-- Privilégios do(a) cliente
GRANT SELECT, INSERT, UPDATE
	ON TF_Tema1_AlexFaustino.CLIENTE
    TO cliente;

GRANT SELECT, INSERT, UPDATE
	ON TF_Tema1_AlexFaustino.PAGAMENTO
    TO cliente;

GRANT SELECT, INSERT, DELETE
	ON TF_Tema1_AlexFaustino.CARTAO
    TO cliente;

GRANT SELECT, INSERT, DELETE
	ON TF_Tema1_AlexFaustino.possui
    TO cliente;

GRANT ALL PRIVILEGES
	ON TF_Tema1_AlexFaustino.AVALIACAO
    TO cliente;

GRANT SELECT
	ON TF_Tema1_AlexFaustino.ATENDIMENTO
    TO cliente;

GRANT SELECT
	ON TF_Tema1_AlexFaustino.atua
    TO cliente;

-- Designando papeis para os Usuarios

GRANT administrador TO Jeysel;
GRANT administrador TO Jhon;
GRANT administrador TO Lennon;

GRANT autonomo TO Jairo;
GRANT autonomo TO Paulo;
GRANT autonomo TO Marcos;
GRANT autonomo TO Gabriel;
GRANT autonomo TO Nicolas;

GRANT cliente TO Davi;
GRANT cliente TO Caina;
GRANT cliente TO Maria;
GRANT cliente TO Carlos;
GRANT cliente TO Mayla;
 










	
