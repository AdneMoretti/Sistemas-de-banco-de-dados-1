-- ---------------------   << TF_Tema1_Apaga_Final_AlexFaustino >>   ---------------------
--
--                                   SCRIPT DE APAGA (DDL)                                   
-- 
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Adne Moreira, Alex Faustino, Ana Massuh, Cainã Freitas, Carlos Nascimento, Cristian Furtado, Davi Silva, Gabriel Oliveira, Gabriel Souza
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_Tema1_AlexFaustino
--
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
--         => 03 Perfis
--         => 13 Usuários
-- 
-- Ultimas Alteracoes
--   06/02/2023 => ADIÇÃO: tabela PAGAMENTO
--              => REMOÇÃO: tabela CONTABANCARIA
--   12/02/2023 => ADIÇÃO: DROP ROLE, DROP USER, tabela atua, compoe
-- 			    => REMOÇÃO: tabela vende
-- 
-- ---------------------------------------------------------

USE TF_Tema1_AlexFaustino;

DROP USER Jeysel;
DROP USER Jhon;
DROP USER Lennon;
DROP USER Davi;
DROP USER Caina;
DROP USER Maria;
DROP USER Carlos;
DROP USER Mayla;
DROP USER Jairo;
DROP USER Paulo;
DROP USER Marcos;
DROP USER Gabriel;
DROP USER Nicolas;
DROP ROLE administrador;
DROP ROLE autonomo;
DROP ROLE cliente;
DROP TABLE atua;
DROP TABLE compoe;
DROP TABLE possui; 
DROP TABLE PAGAMENTO;
DROP TABLE CARTAO;
DROP TABLE AVALIACAO;
DROP TABLE MENSALIDADE;
DROP TABLE SERVICO;
DROP TABLE ATENDIMENTO;
DROP TABLE AUTONOMO;
DROP TABLE CLIENTE;
DROP TABLE AREAATUACAO;
