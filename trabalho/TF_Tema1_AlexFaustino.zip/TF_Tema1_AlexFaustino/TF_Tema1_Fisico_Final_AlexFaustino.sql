-- --------  << TF_Tema1_Fisico_Final_AlexFaustino >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Adne Moreira, Alex Faustino, Ana Massuh, Cainã Freitas, Carlos Nascimento, Cristian Furtado, Davi Silva, Gabriel Oliveira, Gabriel Souza
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_Tema1_AlexFaustino
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
--         => 03 Perfis
--         => 13 Usuários
--
-- Ultimas Alteracoes
--   06/02/2023 => ADIÇÃO: tabela PAGAMENTO
-- 						   atributo composto contabancaria(numeroConta, numeroAgencia) em AUTONOMO
-- 						   atributo descricaoAtendimento em ATENDIMENTO
--              => REMOÇÃO: tabela CONTABANCARIA
--                          atributo diaCobranca em AUTONOMO
--
--   12/02/2023 => ADIÇÃO: tabelas atua e compoe
-- 						   atributos valorServico, tempoServico em SERVICO
-- 					       atributos cpf e numeroCartao como chave unica na tabela possui
-- 						   atributos cpf e dataMensalidade como chave unica na tabela MENSALIDADE
--              => REMOÇÃO: tabela vende, USUARIO
--                         atributo verificacaoAtendimento em ATENDIMENTO
-- 						   atributo cpfTitular na tabela CARTAO
--
--   15/02/2023 => ADIÇÃO: atributos dataCriacaoConta, telefone e sexo em CLIENTE
-- 					       atributos quantidadeAvisos em ATENDIMENTO
--
-- ---------------------------------------------------------


-- BASE DE DADOS
CREATE DATABASE IF NOT EXISTS TF_Tema1_AlexFaustino;
USE TF_Tema1_AlexFaustino;

-- TABELAS
CREATE TABLE CLIENTE (
    cpf BIGINT(11) NOT NULL,
    nomeCompleto VARCHAR(50) NOT NULL,
    email VARCHAR(256) NOT NULL,
    senha INT(6) NOT NULL,
    dataNascimento DATE NOT NULL,
	cep INT(8) NOT NULL,
	uf VARCHAR(2) NOT NULL,
    numero INT(5) NOT NULL,
    pais VARCHAR(30) NOT NULL,
	cidade VARCHAR(50) NOT NULL,
	bairro VARCHAR(50) NOT NULL,
    rua VARCHAR(50) NOT NULL,
    complemento VARCHAR(100),
    diaPagamento INT(2) NOT NULL,
    dataCriacaoConta DATE,
    dddTelefone INT(2),
    numTelefone BIGINT(9),
    
    
 CONSTRAINT CLIENTE_PK PRIMARY KEY(cpf),
 
 CONSTRAINT CLIENTE_email_UK UNIQUE KEY(email)

)ENGINE = InnoDB;

CREATE TABLE AUTONOMO (
    cpfAutonomo BIGINT(11) NOT NULL,
    statusAutonomo ENUM('ativo', 'inativo') NOT NULL,
    numeroConta INT(6) NOT NULL,
    numeroAgencia INT(7) NOT NULL,
    
 CONSTRAINT AUTONOMO_PK PRIMARY KEY(cpfAutonomo),
 
 CONSTRAINT AUTONOMO_CLIENTE_FK FOREIGN KEY(cpfAutonomo)
	REFERENCES CLIENTE(cpf)
    ON DELETE RESTRICT 
    ON UPDATE RESTRICT
        
)ENGINE = InnoDB;

CREATE TABLE CARTAO (
    numeroCartao BIGINT(16) NOT NULL,
    validade DATE NOT NULL,
    nomeTitular VARCHAR(50) NOT NULL,
    cvv INT(3) NOT NULL,
 
	CONSTRAINT CARTAO_PK PRIMARY KEY (numeroCartao)
) ENGINE = InnoDB;

CREATE TABLE possui (
    cpf BIGINT(11) NOT NULL,
    numeroCartao BIGINT(16) NOT NULL,
    
    CONSTRAINT possui_CLIENTE_FK FOREIGN KEY(cpf)
	    REFERENCES CLIENTE(cpf)
        ON DELETE CASCADE,
    
    CONSTRAINT possui_CARTAO_FK FOREIGN KEY(numeroCartao)
	    REFERENCES CARTAO(numeroCartao)
        ON DELETE CASCADE,
	
    CONSTRAINT possui_cpf_numeroCartao_UK UNIQUE KEY(cpf, numeroCartao)
    
)ENGINE = InnoDB;

CREATE TABLE AREAATUACAO (
    idAreaAtuacao INT(5) NOT NULL AUTO_INCREMENT,
    tagAreaAtuacao VARCHAR(50) NOT NULL,
    
	CONSTRAINT AREAATUACAO_PK PRIMARY KEY (idAreaAtuacao)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE MENSALIDADE (
    idMensalidade INT(5) NOT NULL AUTO_INCREMENT, 
    cpfAutonomo BIGINT(11) NOT NULL,
    dataMensalidade DATE NOT NULL,
    statusMensalidade ENUM('Pago', 'Pendente', 'Vencido') NOT NULL,
    valorMensalidade DECIMAL(7,2) NOT NULL,
    
    CONSTRAINT idMensalidade PRIMARY KEY(idMensalidade),
 
    CONSTRAINT MENSALIDADE_AUTONOMO_FK FOREIGN KEY(cpfAutonomo)
	    REFERENCES AUTONOMO(cpfAutonomo)
        ON DELETE RESTRICT 
        ON UPDATE CASCADE,

    CONSTRAINT MENSALIDADE_cpfAutonomo_UK UNIQUE KEY(cpfAutonomo),
    CONSTRAINT MENSALIDADE_dataMensalidade_UK UNIQUE KEY(dataMensalidade)

)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE atua (
	idAreaAtuacao INT(5) NOT NULL,
	cpfAutonomo BIGINT(11) NOT NULL, 

	CONSTRAINT atua_AUTONOMO_FK FOREIGN KEY(cpfAutonomo)
        REFERENCES AUTONOMO(cpfAutonomo) 
        ON DELETE CASCADE,

	CONSTRAINT atua_AREAATUACAO_FK FOREIGN KEY (idAreaAtuacao)
        REFERENCES AREAATUACAO(idAreaAtuacao) 
        ON DELETE CASCADE,

    CONSTRAINT atua_cpfAutonomo_UK UNIQUE KEY(cpfAutonomo),
    CONSTRAINT atua_idAreaAtuacao_UK UNIQUE KEY(idAreaAtuacao)

) ENGINE = InnoDB;

CREATE TABLE ATENDIMENTO (
	idAtendimento INT(5) NOT NULL AUTO_INCREMENT,
    dataAtendimento DATE NOT NULL,
    horaAtendimento TIME NOT NULL,
    descricaoAtendimento VARCHAR(260) NOT NULL,
    statusAtendimento ENUM('APROVADO', 'PENDENTE', 'RECUSADO') NOT NULL,
    cpfAutonomo BIGINT(11) NOT NULL,
    cpfcliente BIGINT(11) NOT NULL,
    quantidadeDeAvisos INT NOT NULL DEFAULT 0,
    
    CONSTRAINT ATENDIMENTO_PK PRIMARY KEY(idAtendimento),
 
    CONSTRAINT ATENDIMENTO_AUTONOMO_FK FOREIGN KEY(cpfAutonomo)
	    REFERENCES AUTONOMO(cpfAutonomo),
    
    CONSTRAINT ATENDIMENTO_CLIENTE_FK FOREIGN KEY(cpfCliente)
	    REFERENCES CLIENTE(cpf)
    
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE AVALIACAO(
	idAvaliacao INT(5) NOT NULL AUTO_INCREMENT,
    notaAvaliacao INT(2) NOT NULL,
    textoAvaliacao VARCHAR(100),
    cpfAutonomo BIGINT(11) NOT NULL,
    cpfcliente BIGINT(11) NOT NULL,
    idAtendimento INT(5) NOT NULL,
    
    CONSTRAINT AVALIACAO_PK PRIMARY KEY(idAvaliacao),
 
    CONSTRAINT AVALIACAO_AUTONOMO_FK FOREIGN KEY(cpfAutonomo)
	    REFERENCES AUTONOMO(cpfAutonomo)
        ON DELETE RESTRICT 
        ON UPDATE CASCADE,
    
    CONSTRAINT AVALIACAO_CLIENTE_FK FOREIGN KEY(cpfCliente)
	    REFERENCES CLIENTE(cpf)
        ON DELETE RESTRICT 
        ON UPDATE CASCADE,

    CONSTRAINT AVALIACAO_ATENDIMENTO_FK FOREIGN KEY(idAtendimento)
	    REFERENCES ATENDIMENTO(idAtendimento)
        ON DELETE RESTRICT 
        ON UPDATE CASCADE
    
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE SERVICO (
    idServico INT(5) NOT NULL AUTO_INCREMENT,
    nomeServico VARCHAR(40) NOT NULL,
    valorServico DECIMAL(7,2) NOT NULL,
    tempoServico TIME NOT NULL,
    idAreaAtuacao INT(5) NOT NULL,
    
    CONSTRAINT SERVICO_PK PRIMARY KEY(idServico),
 
    CONSTRAINT SERVICO_AREATUACAO_FK FOREIGN KEY(idAreaAtuacao)
	    REFERENCES AREAATUACAO(idAreaAtuacao)
    
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE compoe (
    idServico INT(5) NOT NULL,
    idAtendimento INT(5) NOT NULL,
    
    CONSTRAINT compoe_SERVICO_FK FOREIGN KEY(idServico)
	    REFERENCES SERVICO(idServico),
 
    CONSTRAINT compoe_ATENDIMENTO_FK FOREIGN KEY(idAtendimento)
	    REFERENCES ATENDIMENTO(idAtendimento)
    
)ENGINE = InnoDB;


CREATE TABLE PAGAMENTO (
    idPagamento INT(5) NOT NULL AUTO_INCREMENT,
    valorTotalPagamento DECIMAL(7,2) NOT NULL,
    dataPagamento DATE NOT NULL,
    horaPagamento TIME NOT NULL,
    idAtendimento INT(5) NOT NULL,
    cpfAutonomo BIGINT(11) NOT NULL,
    numeroCartao BIGINT(16) NOT NULL,

    CONSTRAINT PAGAMENTO_PK PRIMARY KEY(idPagamento),
 
    CONSTRAINT PAGAMENTO_ATENDIMENTO_FK FOREIGN KEY(idAtendimento)
	    REFERENCES ATENDIMENTO(idAtendimento),
 
    CONSTRAINT PAGAMENTO_AUTONOMO_FK FOREIGN KEY(cpfAutonomo)
	    REFERENCES AUTONOMO(cpfAutonomo),
 
    CONSTRAINT PAGAMENTO_CARTAO_FK FOREIGN KEY(numeroCartao)
	    REFERENCES CARTAO(numeroCartao)
 
)ENGINE = InnoDB AUTO_INCREMENT = 1;



 

