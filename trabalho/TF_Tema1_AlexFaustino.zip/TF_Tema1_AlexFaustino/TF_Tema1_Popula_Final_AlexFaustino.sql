-- ---------------------   << TF_Tema1_Popula_Final_AlexFaustino  >>   ---------------------
--
--                                   SCRIPT DE POPULA (DML)                                   
-- 
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Adne Moreira, Alex Faustino, Ana Massuh, Cainã Freitas, Carlos Nascimento, Cristian Furtado, Davi Silva, Gabriel Oliveira, Gabriel Souza
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_Tema1_AlexFaustino
--
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
--         => 03 Perfis
--         => 13 Usuários
--
-- Ultimas Alteracoes
--   06/02/2023 => ADIÇÃO: valores para a tabela PAGAMENTO
--                         valores dos atributos da tabela USUARIO para a tabela CLIENTE
-- 						   valores para o atributo composto contabancaria(numeroConta, numeroAgencia) em AUTONOMO
-- 						   valores para o atributo descricaoAtendimento em ATENDIMENTO
--              => REMOÇÃO: tabela CONTABANCARIA
--                          atributo diaCobranca em AUTONOMO
-- 
--   12/02/2023 => ADIÇÃO: valores para as tabelas atua e compoe
-- 						   valores para os atributos valorServico, tempoServico em SERVICO
--              => REMOÇÃO: tabela vende, USUARIO
--                         atributo verificacaoAtendimento em ATENDIMENTO
-- 						   atributo cpfTitular na tabela CARTAO
--
--   15/02/2023 => ADIÇÃO: valores para os atributos dataCriacaoConta, telefone e sexo em CLIENTE
-- 
-- ---------------------------------------------------------

USE TF_Tema1_AlexFaustino;

INSERT INTO CLIENTE
    (cpf, nomeCompleto, email, senha, dataNascimento, cep, uf, numero, pais, cidade, bairro, rua, complemento, diaPagamento, dataCriacaoConta, dddTelefone, numTelefone)
VALUES
    (89987039049, 'Carlos Santana da Silva', 'Canatnas21@hotmail.com', 21801, '2000-01-21', '71070512', 'DF', 12, 'Brasil', 'Brasilia', 'Guara 2 QE 40 Polo de Modas', '16', 'perto da academia', 10, '2023-01-23', 51, 982736432),
    (73655499043, 'Laura Gomes Oliveira', 'Lsemog20@gmail.com', 20702, '2002-02-20', '71015128', 'DF', 16, 'Brasil', 'Brasilia', 'Guara 1 QI 22', '2', 'casa branca de 2 andares', 13,'2023-01-23', 51, 982736432),
    (08784919027, 'Gabriel Santos Lima', 'Gsotnas21@gmail.com', 16208, '1992-08-12', '49072673', 'SE', 2, 'Brasil', 'Aracaju', 'Dezoito do Forte', '20', 'perto da praia', 23, '2023-01-23', 22, 982236432),
    (67559688039, 'Lucas Ribeiro Carvalho', 'Loriebir2@hotmail.com', 50212, '1990-12-02', '99072460', 'RS', 4, 'Brasil', 'Passo Fundo', 'Santa Maria', '13', 'Casa com flores na entrada', 30, '2023-01-23', 22, 932545678),
    (41461044081, 'Bruno Campos Manet', 'Bsopmac21@gmail.com',21101, '2000-01-21', '71070513', 'DF', 6, 'Brasil', 'Brasilia', 'Santa Maria', '101', 'Porta cinza', 14, '2023-01-23', 61, 928829177),
    (08740790045, 'Monica Souza de Palmeira', 'Mazuos@gmail.com', 41101, '1990-01-21', '37716045', 'GO', 7, 'Brasil', 'Poços de Caldas', 'Joao Maria Casalinho', 'Santa Angela IV', 'perto do lago', 17, '2023-01-23', 21, 984521088),
    (60607520043, 'Suzana Vieira da Costa', 'Sarieiv@hotmail.com', 41002, '1986-02-20', '54759765', 'PE', 17, 'Brasil', 'Camaragibe', 'Jardim Eldorado', 'Novo do Carmelo', 'Porta cinza', 08, '2023-01-23', 62, 936667311),
    (39301140039, 'Maria Silva da Silva', 'Mavlis@gmail.com', 11202, '1992-02-12', '69316748', 'RR', 20, 'Brasil', 'Boa Vista', 'Antônia Ferreira', '11', 'Casa vermelha', 02, '2023-01-23', 53, 981643449),
    (01535738057, 'Mirna Lucia de Lima', 'Maicul@gmail.com', 22219, '1992-11-02', '29043053', 'BA', 20, 'Brasil', 'Vitoria', 'Rufino Azevedo', 'Maruipe', 'Primeira casa da rua', 10, '2023-01-23', 61, 943467311),
    (22427739170, 'Julia Matos Gomes da Silva', 'Jsotam@gmail.com', 34101, '1975-01-21', '65055540', 'MA', 18, 'Brasil', 'São Luís', 'Cleonice Lopes', 'São Cristovão', 'lote aberto', 09, '2023-01-23', 22, 982938282);

INSERT INTO AUTONOMO
	(cpfAutonomo, statusAutonomo, numeroConta, numeroAgencia)
VALUES
	(08740790045, 'ativo', 12442078, 1037),
    (60607520043, 'ativo', 28106587, 6962),
    (39301140039, 'ativo', 31801046, 1931),
    (01535738057, 'ativo', 41456822, 2914),
    (22427739170, 'ativo', 51573098, 3520),
    (89987039049, 'ativo', 07840659, 1736),
    (73655499043, 'ativo', 02038749, 2065),
    (08784919027, 'ativo', 08724342, 2557),
    (67559688039, 'ativo', 05559480, 0808),
    (41461044081, 'ativo', 12248318, 0088);

INSERT INTO CARTAO
	(numeroCartao, validade, nomeTitular, cvv)
VALUES
	(5394918387338730, '2023-09-25', 'Carlos Santana da Silva', 920),
    (4929857471421381, '2024-10-25', 'Laura Gomes Oliveira', 776),
    (4716775807379338, '2023-09-25', 'Gabriel Santos Lima', 636),
    (5179612782588004, '2024-04-25', 'Lucas Ribeiro Carvalho', 969),
    (5239065870350902, '2024-05-25', 'Bruno Campos Manet', 750),
    (4916675975332218, '2024-04-25', 'Monica Souza de Palmeira', 292),
    (5123402497740299, '2025-01-25', 'Suzana Vieira da Costa', 458),
    (4532604504596030, '2024-06-25', 'Maria Silva da Silva', 521),
    (5301830901869037, '2024-02-25', 'Mirna Lucia de Lima', 184),
    (4556035530975107, '2023-06-25', 'Julia Matos Gomes da Silva', 892);
    
INSERT INTO possui
	(cpf, numeroCartao)
VALUES
	(89987039049, 5394918387338730),
    (73655499043, 4929857471421381),
    (08784919027, 4716775807379338),
    (67559688039, 5179612782588004),
    (41461044081, 5239065870350902),
    (08740790045, 4916675975332218),
    (60607520043, 5123402497740299),
    (39301140039, 4532604504596030),
    (01535738057, 5301830901869037),
    (22427739170, 4556035530975107);

INSERT INTO AREAATUACAO
	(tagAreaAtuacao)
VALUES
	('Estética'),
    ('Educação financeira'),
    ('Educação física'),
    ('Eletricista'),
    ('Nutrição'),
    ('Medicina Veterinária'),
    ('Farmácia'),
    ('Fonoaudiologia'),
    ('Quiropraxia'),
    ('Odontologia');

INSERT INTO MENSALIDADE
	(cpfAutonomo, dataMensalidade, statusMensalidade, valorMensalidade)
VALUES
	(08740790045, '2023-01-10', 'Pago', 45),
    (60607520043, '2023-01-1', 'Pago', 45),
    (39301140039, '2023-01-30', 'Pago', 45),
    (01535738057, '2023-01-25', 'Pago', 45),
    (22427739170, '2023-01-24', 'Pago', 45),
    (89987039049, '2023-02-10', 'Pago', 45),
    (73655499043, '2023-02-11', 'Pago', 45),
    (08784919027, '2023-02-12', 'Pago', 45),
    (67559688039, '2023-02-13', 'Pendente', 45),
    (41461044081, '2023-02-14', 'Pendente', 45);

INSERT INTO atua
    (idAreaAtuacao, cpfAutonomo)
VALUES
    (1, 08740790045),
    (2, 60607520043),
    (3, 39301140039),
    (4, 01535738057),
    (5, 22427739170),
    (6, 89987039049),
    (7, 73655499043),
    (8, 08784919027),
    (9, 67559688039),
    (10, 41461044081);

INSERT INTO ATENDIMENTO
	(dataAtendimento, horaAtendimento, descricaoAtendimento, statusAtendimento, cpfAutonomo, cpfcliente)
VALUES
	('2023-01-10', '14:00:00', 'Sessão de cuidados com cutículas, limpeza e esmaltação', 'APROVADO', 08740790045, 89987039049),
	('2023-01-11', '16:00:00', 'Aula de como investir na bolsa de valores', 'APROVADO', 60607520043, 89987039049),
	('2023-01-10', '15:30:00', 'Aula de fitdance(Anitta - se prepara)', 'RECUSADO', 60607520043, 73655499043),
	('2023-01-15', '10:00:00', 'Treino de costa/biceps e aula de fitdance(Deboche - Leo Santana)', 'APROVADO', 39301140039, 73655499043),
	('2023-01-16', '11:00:00', 'Instalação, troca e limpeza de chuveiro elétrico', 'APROVADO', 01535738057, 08784919027),
	('2023-01-17', '11:00:00', 'Aula de fitdance(Olha a explosão - MC Kevinho)', 'APROVADO', 39301140039, 67559688039),
	('2023-01-18', '13:00:00', 'Entrevista (anamnese) para obter dados sobre a doença atual e outras informações específicas para a construção do plano alimentar', 'APROVADO', 22427739170, 41461044081),
    ('2023-02-11', '11:30:00', 'Consulta odontológica para avaliação do uso de aparelho bucal', 'APROVADO', 73655499043, 01535738057),
    ('2023-02-12', '14:00:00', 'Consulta terápica ligada à linguagem oral e escrita', 'APROVADO', 08784919027, 08740790045),
    ('2023-02-13', '16:30:00', 'Consulta de diagnóstico de problemas do sistema neuro-músculo-esquelético', 'APROVADO', 67559688039, 39301140039),
    ('2023-02-14', '17:00:00', 'Consulta de assistência clinica a animal doméstico', 'APROVADO', 41461044081, 22427739170);


INSERT INTO AVALIACAO
	(notaAvaliacao, textoAvaliacao, cpfAutonomo, cpfcliente, idAtendimento)
VALUES
	(10, 'Excelente profissional.', 08740790045, 89987039049, 1),
    (4, 'O serviço não saiu como esperado.', 60607520043, 89987039049, 2),
    (10, 'Profissional altamente capaz!', 39301140039, 73655499043, 4),
    (9, 'Atendimento maravilhoso!', 01535738057, 08784919027, 5),
    (10, 'Ganhou uma cliente fixa, atendimento bom demais!!', 39301140039, 67559688039, 6),
    (9, 'Gostei demais!!', 22427739170, 41461044081, 7),
    (2, 'Fiquei com muita dor de dente após o procedimento', 73655499043, 01535738057, 8),
    (9, 'Me atendeu super bem, apesar de ter se atrasado um pouco.', 08784919027, 08740790045, 9),
    (10, 'Me sinto 5 anos mais jovem depois desta consulta.', 67559688039, 39301140039, 10),
    (10, 'Pronto atendimento excelente!!', 41461044081, 22427739170, 11);
	
INSERT INTO SERVICO
	(nomeServico, idAreaAtuacao, valorServico, tempoServico)
VALUES
	('Manicure', 1, 50, '00:40:00'),
    ('Aula de educação financeira', 2, 200, '02:00:00'),
    ('Acompanhamento Personal trainer', 3, 250, '02:00:00'),
    ('Conserto de chuveiro elétrico', 4, 250, '02:00:00'),
    ('Aula de fitdance', 3, 140, '00:34:30'),
    ('Consulta nutricionista', 5, 250, '00:50:00'),
    ('Consulta dentista', 10, 250, '00:34:30'),
    ('Treino de oratória', 8, 250, '01:00:00'),
    ('Sessão de quiropraxia', 9, 300, '00:40:00'),
    ('Banho de animal doméstico', 6, 150, '00:56:45');

INSERT INTO compoe
	(idServico, idAtendimento)
VALUES
	(1, 1),
    (2, 2), 
    (3, 4), 
    (5, 4),
    (4, 5),
    (5, 6),
    (6, 7),
    (7, 8),        
    (8, 9),    
    (9, 10),    
    (10, 11);

INSERT INTO PAGAMENTO
    (dataPagamento, horaPagamento, valorTotalPagamento, idAtendimento, cpfAutonomo, numeroCartao)
VALUES
    ('2023-01-09', '10:00:04', 50, 1, 08740790045, 5394918387338730),
    ('2023-01-10', '11:34:02', 200, 2, 60607520043, 5394918387338730),
    ('2023-01-14', '20:39:31', 390, 4, 39301140039, 4929857471421381),
    ('2023-01-15', '09:10:20', 250, 5, 01535738057, 4716775807379338),
    ('2023-01-16', '18:30:10', 140, 6, 39301140039, 5179612782588004),
    ('2023-01-17', '11:30:40', 250, 7, 22427739170, 5239065870350902),
    ('2023-02-11', '11:30:00', 250, 8, 73655499043, 4929857471421381),
    ('2023-02-12', '14:00:00', 250, 9,  08784919027, 4716775807379338),
    ('2023-02-13', '16:30:00', 300, 10, 67559688039, 5179612782588004),
    ('2023-02-14', '17:00:00', 150, 11, 41461044081, 5239065870350902);
