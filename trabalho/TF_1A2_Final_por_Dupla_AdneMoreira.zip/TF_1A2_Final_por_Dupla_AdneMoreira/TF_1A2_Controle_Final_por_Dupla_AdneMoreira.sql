--   ----------------- TF_scripts ----------------
--                    SCRIPT DE CONTROLE (DCL)
--
-- Data Criacao ...........: 05/02/2023
-- Autor(es) ..............: Adne Moretti Moreira, Ana Beatriz Massuh
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A2_AdneMoreira
--            
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--         => 03 Usuarios
--         => 03 Perfis
--
-- ---------------------------------------------------------

USE TF_1A2_AdneMoreira;

-- Criacao de perfil
CREATE ROLE USUARIO;
CREATE ROLE AUTONOMO;
CREATE ROLE ADMINISTRADOR;
   
-- Atribuindo privilegios
GRANT ALL PRIVILEGES ON TF_1A2_AdneMoreira.* TO ADMINISTRADOR;
-- Autonomo
GRANT UPDATE, SELECT, INSERT ON TF_1A2_AdneMoreira.FORNECEDOR TO AUTONOMO;
GRANT UPDATE, SELECT, INSERT ON TF_1A2_AdneMoreira.AREAATUACAO TO AUTONOMO;
GRANT SELECT, INSERT ON TF_1A2_AdneMoreira.MENSALIDADE TO AUTONOMO;
GRANT ALL PRIVILEGES ON TF_1A2_AdneMoreira.SERVICO TO AUTONOMO;
GRANT ALL PRIVILEGES ON TF_1A2_AdneMoreira.atua TO AUTONOMO;
GRANT SELECT ON TF_1A2_AdneMoreira.AVALIACAO  TO AUTONOMO;
GRANT SELECT ON TF_1A2_AdneMoreira.PAGAMENTO  TO AUTONOMO;
GRANT SELECT ON TF_1A2_AdneMoreira.AVALIACAO  TO AUTONOMO;
-- Usuario
GRANT UPDATE, SELECT, INSERT ON TF_1A2_AdneMoreira.CLIENTE TO USUARIO;
GRANT UPDATE, SELECT, INSERT ON TF_1A2_AdneMoreira.PAGAMENTO TO USUARIO;
GRANT SELECT, INSERT, DELETE ON TF_1A2_AdneMoreira.CARTAO TO USUARIO;
GRANT SELECT, INSERT, DELETE ON TF_1A2_AdneMoreira.possui TO USUARIO;
GRANT ALL PRIVILEGES ON TF_1A2_AdneMoreira.AVALIACAO TO USUARIO;
GRANT SELECT ON TF_1A2_AdneMoreira.SERVICO TO USUARIO;
GRANT SELECT ON TF_1A2_AdneMoreira.SERVICO TO USUARIO;
GRANT SELECT ON TF_1A2_AdneMoreira.atua TO USUARIO;

-- Criacao de usuário
CREATE USER 'EvelynTeresinhaDC' IDENTIFIED BY 'daCosta123';
CREATE USER 'MelissaAndreaDA' IDENTIFIED BY 'DaianeAssis';
CREATE USER 'AdministradorJoao' IDENTIFIED BY 'admin1233';

-- Atribuindo perfil
GRANT USUARIO TO 'EvelynTeresinhaDC';
GRANT AUTONOMO TO 'MelissaAndreaDA';
GRANT ADMINISTRADOR TO 'AdministradorJoao';
