-- ---------------------   << TF_Popula_Tema1  >>   ---------------------
--
--                                   SCRIPT DE POPULA (DML)                                   
-- 
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Cainã Valença de Freitas - 180014412, Davi Lima da Silva - 190026588
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_Tema1
--
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
-- ---------------------------------------------------------

USE TF_Tema1;

INSERT INTO USUARIO
    (cpf, nomeUsuario, email, senha, dataNascimento, cep, uf, numero, pais, cidade, bairro, rua, complemento)
VALUES
    (89987039049, 'Carlos Santana da Silva', 'Canatnas21@hotmail.com', 21801, '2000-01-21', '71070512', 'DF', 12, 'Brasil', 'Brasilia', 'Guara 2 QE 40 Polo de Modas', '16', 'perto da academia'),
    (73655499043, 'Laura Gomes Oliveira'	  , 'Lsemog20@gmail.com', 20702, '2002-02-20', '71015128', 'DF', 16, 'Brasil', 'Brasilia', 'Guara 1 QI 22', '2', 'casa branca de 2 andares'),
    (08784919027, 'Gabriel Santos Lima', 'Gsotnas21@gmail.com', 16208, '1992-08-12', '49072673', 'SE', 2, 'Brasil', 'Aracaju', 'Dezoito do Forte', '20', 'perto da praia'),
    (67559688039, 'Lucas Ribeiro Carvalho' , 'Loriebir2@hotmail.com', 50212, '1990-12-02', '99072460', 'RS', 4, 'Brasil', 'Passo Fundo', 'Santa Maria', '13', 'Casa com flores na entrada'),
    (41461044081, 'Bruno Campos Manet'  , 'Bsopmac21@gmail.com',21101, '2000-01-21', '71070513', 'DF', 6, 'Brasil', 'Brasilia', 'Santa Maria', '101', 'Porta cinza'),
    (08740790045, 'Monica Souza de Palmeira'  , 'Mazuos@gmail.com', 41101, '1990-01-21', '37716045', 'GO', 7, 'Brasil', 'Poços de Caldas', 'Joao Maria Casalinho', 'Santa Angela IV', 'perto do lago'),
    (60607520043, 'Suzana Vieira da Costa' , 'Sarieiv@hotmail.com', 41002, '1986-02-20', '54759765', 'PE', 17, 'Brasil', 'Camaragibe', 'Jardim Eldorado', 'Novo do Carmelo', 'Porta cinza'),
    (39301140039, 'Maria Silva da Silva'   , 'Mavlis@gmail.com', 11202, '1992-02-12', '69316748', 'RR', 20, 'Brasil', 'Boa Vista', 'Antônia Ferreira', '11', 'Casa vermelha'),
    (01535738057, 'Mirna Lucia de Lima'   , 'Maicul@gmail.com', 22219, '1992-11-02', '29043053', 'BA', 20, 'Brasil', 'Vitoria', 'Rufino Azevedo', 'Maruipe', 'Primeira casa da rua'),
    (22427739170, 'Julia Matos Gomes da Silva'   , 'Jsotam@gmail.com', 34101, '1975-01-21', '65055540', 'MA', 18, 'Brasil', 'São Luís', 'Cleonice Lopes', 'São Cristovão', 'lote aberto');

INSERT INTO CARTAO
	(numeroCartao, validade, nomeTitular, cpfTitular, cvv)
VALUES
	(5394918387338730, '2023-09-25', 'Carlos Santana da Silva', 89987039049, 920),
    (4929857471421381, '2024-10-25', 'Laura Gomes Oliveira', 73655499043, 776),
    (4716775807379338, '2023-09-25', 'Gabriel Santos Lima', 08784919027, 636),
    (5179612782588004, '2024-04-25', 'Lucas Ribeiro Carvalho', 67559688039, 969),
    (5239065870350902, '2024-05-25', 'Bruno Campos Manet', 41461044081, 750),
    (4916675975332218, '2024-04-25', 'Monica Souza de Palmeira', 08740790045, 292),
    (5123402497740299, '2025-01-25', 'Suzana Vieira da Costa', 60607520043, 458),
    (4532604504596030, '2024-06-25', 'Maria Silva da Silva', 39301140039, 521),
    (5301830901869037, '2024-02-25', 'Mirna Lucia de Lima', 01535738057, 184),
    (4556035530975107, '2023-06-25', 'Julia Matos Gomes da Silva', 22427739170, 892);
    
INSERT INTO possui
	(cpf, numeroCartao)
VALUES
	(89987039049, 5394918387338730),
    (73655499043, 4929857471421381),
    (08784919027, 4716775807379338),
    (67559688039, 5179612782588004),
    (41461044081, 5239065870350902),
    (08740790045, 4916675975332218),
    (60607520043, 5123402497740299),
    (39301140039, 4532604504596030),
    (01535738057, 5301830901869037),
    (22427739170, 4556035530975107);

INSERT INTO CLIENTE
	(cpfCliente, diaPagamento)
VALUES
	(89987039049, 10),
    (73655499043, 1),
    (08784919027, 30),
    (67559688039, 4),
    (41461044081, 10);

INSERT INTO AREAATUACAO
	(tagAreaAtuacao)
VALUES
	('Estética'),
    ('Educação financeira'),
    ('Educação física'),
    ('Eletricista'),
    ('Nutrição');

INSERT INTO AUTONOMO
	(cpfAutonomo, ativo, diaCobranca, idAreaAtuacao)
VALUES
	(08740790045, true, 10, 1),
    (60607520043, true, 1, 2),
    (39301140039, true, 30, 3),
    (01535738057, true, 25, 4),
    (22427739170, true, 24, 5);

INSERT INTO MENSALIDADE
	(cpfAutonomo, dataMensalidade, statusMensalidade, valor)
VALUES
	(08740790045, '2023-01-10', 'Pago', 45),
    (60607520043, '2023-01-1', 'Pago', 45),
    (39301140039, '2023-01-30', 'Pendente', 45),
    (01535738057, '2023-01-25', 'Pago', 45),
    (22427739170, '2023-01-24', 'Pago', 45);

INSERT INTO CONTABANCARIA
	(numeroConta, numeroAgencia, cpfAutonomo)
VALUES
	(2442078, 1037, 08740790045),
    (8106587, 6962, 60607520043),
    (1801046, 1931, 39301140039),
    (1456822, 2914, 01535738057),
    (1573098, 3520, 22427739170);

INSERT INTO ATENDIMENTO
	(dataAtendimento, horaAtendimento, statusAtendimento, statusVerificacao, dataVerificacao, cpfAutonomo, cpfcliente)
VALUES
	('2023-01-10', '14:00:00', true, 'APROVADO', '2023-01-09', 08740790045, 89987039049),
	('2023-01-11', '16:00:00', true, 'APROVADO', '2023-01-10', 60607520043, 89987039049),
	('2023-01-10', '15:30:00', false, 'RECUSADO', '2023-01-09', 60607520043, 73655499043),
	('2023-01-15', '10:00:00', true, 'APROVADO', '2023-01-14', 39301140039, 73655499043),
	('2023-01-16', '11:00:00', true, 'APROVADO', '2023-01-15', 01535738057, 08784919027),
	('2023-01-17', '11:00:00', true, 'APROVADO', '2023-01-16', 39301140039, 67559688039),
	('2023-01-18', '13:00:00', true, 'APROVADO', '2023-01-17', 22427739170, 41461044081);

INSERT INTO AVALIACAO
	(notaAvaliacao, textoAvaliacao, cpfAutonomo, cpfcliente, idAtendimento)
VALUES
	(10, 'Excelente profissional.', 08740790045, 89987039049, 1),
    (4, 'O serviço não saiu como esperado.', 60607520043, 89987039049, 2),
    (10, 'Profissional altamente capaz!', 39301140039, 73655499043, 4),
    (9, 'Atendimento maravilhoso!', 01535738057, 08784919027, 5),
    (10, 'Ganhou uma cliente fixa, atendimento bom demais!!', 39301140039, 67559688039, 6),
    (9, 'Gostei demais!!', 22427739170, 41461044081, 7);
	
INSERT INTO SERVICO
	(nomeServico, idAreaAtuacao)
VALUES
	('Manicure', 1),
    ('Aula de educação financeira', 2),
    ('Acompanhamento Personal trainer', 3),
    ('Conserto de chuveiro elétrico', 4),
    ('Aula de fitdance', 3),
    ('Consulta nutricionista', 5);
    
INSERT INTO vende
	(idServico, idAtendimento, valorServico, tempoServico)
VALUES
	(1, 1, 50, '00:40:00'),
    (2, 2, 200, '02:00:00'),
    (3, 4, 250, '02:00:00'),
    (4, 5, 140, '00:34:30'),
    (5, 6, 300, '01:30:00'),
    (6, 7, 250, '00:50:00');
    