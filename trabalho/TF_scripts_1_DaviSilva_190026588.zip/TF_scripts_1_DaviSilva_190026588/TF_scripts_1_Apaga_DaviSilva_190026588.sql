-- ---------------------   << TF_Apaga_Tema1 >>   ---------------------
--
--                                   SCRIPT DE APAGA (DDL)                                   
-- 
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Cainã Valença de Freitas - 180014412, Davi Lima da Silva - 190026588
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_Tema1
--
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
-- ---------------------------------------------------------

USE TF_Tema1;

DROP TABLE vende;
DROP TABLE SERVICO;
DROP TABLE AVALIACAO;
DROP TABLE ATENDIMENTO;
DROP TABLE CONTABANCARIA;
DROP TABLE MENSALIDADE;
DROP TABLE AUTONOMO;
DROP TABLE AREAATUACAO;
DROP TABLE CLIENTE;
DROP TABLE possui;
DROP TABLE CARTAO;
DROP TABLE USUARIO;