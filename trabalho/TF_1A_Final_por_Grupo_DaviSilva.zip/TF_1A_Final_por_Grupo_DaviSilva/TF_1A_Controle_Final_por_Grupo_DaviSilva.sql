-- ---------------------   << TF_1A_Controle_Final_por_Grupo_DaviSilva >>   ---------------------
--
--                                   SCRIPT DE CONTROLE (DDL)                                   
-- 
-- Data Criacao ...........: 06/02/2023
-- Autor(es) ..............: Adne Moreira, Ana Massuh, Cainã Freitas, Davi Silva 
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A_DaviSilva
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
--         => 03 Perfis
--         => 12 Usuários
--
-- Ultimas Alteracoes
--   12/02/2023 => ALTERACAO: Nome dos perfis
-- 
-- ---------------------------------------------------------

USE TF_1A_DaviSilva;

-- Criando os Perfis do projeto	
CREATE ROLE administrador;
CREATE ROLE autonomo;
CREATE ROLE cliente;	

-- Criando Usuarios do Projeto 

CREATE USER Jeysel
	IDENTIFIED BY 'lesyeJ2023!';

CREATE USER Jhon
	IDENTIFIED BY 'nohJ2023!';

CREATE USER Lennon
	IDENTIFIED BY 'nonneL2023!';
    
CREATE USER Davi
	IDENTIFIED BY 'ivaD2023.';

CREATE USER Caina
	IDENTIFIED BY 'aniaC2023!';
  
CREATE USER Maria
	IDENTIFIED BY 'airaM2023.';
  
CREATE USER Carlos
	IDENTIFIED BY 'solraC2023!';

CREATE USER Mayla
	IDENTIFIED BY 'alyaM2023.';

CREATE USER Jairo
	IDENTIFIED BY 'oriaJ2023!';

CREATE USER Paulo
	IDENTIFIED BY 'oluaP2023.';

CREATE USER Marcos
	IDENTIFIED BY 'socraM2023!';
    
CREATE USER Gabriel
	IDENTIFIED BY 'leirbaG2023.';

CREATE USER Nicolas
	IDENTIFIED BY 'salociN2023!';
    
-- Privilégios do administrador
GRANT ALL PRIVILEGES 
	ON TF_1A_DaviSilva.* 
    TO administrador;
    
-- Privilégios do(a) autonomo
GRANT SELECT
	ON TF_1A_DaviSilva.CLIENTE
    TO autonomo;  

GRANT SELECT, INSERT, UPDATE
	ON TF_1A_DaviSilva.AUTONOMO
    TO autonomo;  

GRANT SELECT, INSERT
	ON TF_1A_DaviSilva.AREAATUACAO
    TO autonomo;

GRANT SELECT
	ON TF_1A_DaviSilva.MENSALIDADE
    TO autonomo; 
    
GRANT SELECT, UPDATE, INSERT
	ON TF_1A_DaviSilva.SERVICO
    TO autonomo;

GRANT ALL PRIVILEGES 
	ON TF_1A_DaviSilva.atua
    TO autonomo;

GRANT ALL PRIVILEGES 
	ON TF_1A_DaviSilva.compoe
    TO autonomo;

GRANT SELECT
	ON TF_1A_DaviSilva.AVALIACAO
    TO autonomo;

GRANT SELECT
	ON TF_1A_DaviSilva.PAGAMENTO
    TO autonomo;

GRANT SELECT, UPDATE, INSERT
	ON TF_1A_DaviSilva.ATENDIMENTO
    TO autonomo;
    
-- Privilégios do(a) cliente
GRANT SELECT, INSERT, UPDATE
	ON TF_1A_DaviSilva.CLIENTE
    TO cliente;

GRANT SELECT, INSERT, UPDATE
	ON TF_1A_DaviSilva.PAGAMENTO
    TO cliente;

GRANT SELECT, INSERT, DELETE
	ON TF_1A_DaviSilva.CARTAO
    TO cliente;

GRANT SELECT, INSERT, DELETE
	ON TF_1A_DaviSilva.possui
    TO cliente;

GRANT ALL PRIVILEGES
	ON TF_1A_DaviSilva.AVALIACAO
    TO cliente;

GRANT SELECT
	ON TF_1A_DaviSilva.ATENDIMENTO
    TO cliente;

GRANT SELECT
	ON TF_1A_DaviSilva.atua
    TO cliente;

-- Designando papeis para os Usuarios

GRANT administrador TO Jeysel;
GRANT administrador TO Jhon;
GRANT administrador TO Lennon;

GRANT autonomo TO Jairo;
GRANT autonomo TO Paulo;
GRANT autonomo TO Marcos;
GRANT autonomo TO Gabriel;
GRANT autonomo TO Nicolas;

GRANT cliente TO Davi;
GRANT cliente TO Caina;
GRANT cliente TO Maria;
GRANT cliente TO Carlos;
GRANT cliente TO Mayla;
 










	
