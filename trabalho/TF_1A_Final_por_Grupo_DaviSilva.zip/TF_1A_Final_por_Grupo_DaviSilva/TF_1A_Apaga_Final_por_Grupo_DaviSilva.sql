-- ---------------------   << TF_1A_Apaga_Final_por_Grupo_DaviSilva >>   ---------------------
--
--                                   SCRIPT DE APAGA (DDL)                                   
-- 
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Adne Moreira, Ana Massuh, Cainã Freitas, Davi Silva 
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A_DaviSilva
--
-- PROJETO => 01 Base de Dados
--         => 12 Tabelas
--         => 03 Perfis
--         => 12 Usuários
-- 
-- Ultimas Alteracoes
--   06/02/2023 => ADIÇÃO: tabela PAGAMENTO
--              => REMOÇÃO: tabela CONTABANCARIA
--   12/02/2023 => ADIÇÃO: DROP ROLE, DROP USER, tabela atua, compoe
-- 			    => REMOÇÃO: tabela vende
-- 
-- ---------------------------------------------------------

USE TF_1A_DaviSilva;

DROP USER Jeysel;
DROP USER Jhon;
DROP USER Lennon;
DROP USER Davi;
DROP USER Caina;
DROP USER Maria;
DROP USER Carlos;
DROP USER Mayla;
DROP USER Jairo;
DROP USER Paulo;
DROP USER Marcos;
DROP USER Gabriel;
DROP USER Nicolas;
DROP ROLE administrador;
DROP ROLE autonomo;
DROP ROLE cliente;
DROP TABLE atua;
DROP TABLE compoe;
DROP TABLE possui; 
DROP TABLE PAGAMENTO;
DROP TABLE CARTAO;
DROP TABLE AVALIACAO;
DROP TABLE MENSALIDADE;
DROP TABLE SERVICO;
DROP TABLE ATENDIMENTO;
DROP TABLE AUTONOMO;
DROP TABLE CLIENTE;
DROP TABLE AREAATUACAO;